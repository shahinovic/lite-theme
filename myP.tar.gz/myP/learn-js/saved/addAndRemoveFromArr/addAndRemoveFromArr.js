let current = document.querySelector('[title="Current"]');
let addCl = document.querySelector('.classes-to-add');
let remCl = document.querySelector('.classes-to-remove');
let addVl = document.querySelector('.classes-to-add').value;
let addRes   = document.querySelector('.classes-to-add').value.split(' ');

//work 
document.querySelector('.classes-to-add').onblur = function (e) {
  let span = document.createElement('span');
span.innerHTML = 'No Classes To Show';
  if (document.querySelector('.classes-to-add').value !== '') {
    let resu = function () {

    if (document.querySelector('.classes-to-add').value.split(' ').length > 1) {
      // if you inter more than one word in the input fild 
      let res = document.querySelector('.classes-to-add').value.split(' ').reduce(function (acc, current) {
            
        acc = acc.split('').reduce(function (nAcc, nCurrent) {
            return nAcc.toLowerCase() + nCurrent.toLowerCase();
        });
        current = current.split('').reduce(function (sAcc, sCurrent) {
            return sAcc.toLowerCase() + sCurrent.toLowerCase();
          });
        return acc + " " + current;
      });
      return res;
    } else if (document.querySelector('.classes-to-add').value.split(' ').length = 1) {
      // if you enter one word in the input fild
      let chRes = document.querySelector('.classes-to-add').value.split(' ')[0].split('');
      if (chRes.length > 1) {
        // if the word have more than one liter 
            let res = chRes.reduce(function (acc, current) {
              acc =  acc.toLowerCase();
              current =  current.toLowerCase();
              return acc + current;
            });
            return res;
          } else {
            // if it have one liter
            let res = document.querySelector('.classes-to-add').value.split(' ')[0].toLowerCase();
            return res;
            
          }
      }
    }
    let resPoints = resu().split(' ');
    resPoints.sort();
    if (resu().split(' ').length > 1) {
    for(let i = 0; i < resPoints.length; i++) {
      if (! current.classList.contains(`${resPoints[i]}`)) {
        current.classList.add(`${resPoints[i]}`);
      }

    }
    } else if (resu().split(' ').length === 1) {
      if (resu().split(' ')[0].length > 1) {
        current.classList.add(`${resPoints[0]}`);
      } else {
        current.classList.add(`${resPoints[0]}`);
      }
    }
// addition the res (string) to current element ass a class 

  // if condition to add span his inner text is the classes of current element
      if (current.classList.length === 0) {
          let spanC = span.cloneNode(true);
          // console.log(`res value => (${res}document.querySelector('.classes-list').lastElementChild.append(spanC);)`)
            } else {
                for (let i = 0; i < current.classList.length; i++) {
                    let spanC = span.cloneNode();
                    spanC.innerHTML = `${current.classList[i]}`;
                    spanC.title = `${current.classList[i]}`;
                    if (typeof document.querySelector(`[title="${current.classList[i]}"]`) == 'undefined' || document.querySelector(`[title="${document.querySelector('[title="Current"]').classList[i]}"]`) == null) {
                      document.querySelector('.classes-list').lastElementChild.appendChild(spanC);
                    }
                  }
            }
            document.querySelector('.classes-to-add').value = '';
    } else {
      let span = document.createElement('span');
span.innerHTML = 'No Classes To Show';
      let noCl = document.createTextNode('no classes');
      document.querySelector('.classes-list').lastElementChild.appendChild(noCl);
    
          };
};  
document.querySelector('.classes-to-remove').onblur = function (e) {
  let span = document.createElement('span');
span.innerHTML = 'No Classes To Show';
  if (document.querySelector('.classes-to-remove').value !== '') {
    let resu = function () {

    if (document.querySelector('.classes-to-remove').value.split(' ').length > 1) {
      // if you inter more than one word in the input fild 
      let res = document.querySelector('.classes-to-remove').value.split(' ').reduce(function (acc, current) {
            
        acc = acc.split('').reduce(function (nAcc, nCurrent) {
            return nAcc.toLowerCase() + nCurrent.toLowerCase();
        });
        current = current.split('').reduce(function (sAcc, sCurrent) {
            return sAcc.toLowerCase() + sCurrent.toLowerCase();
          });
        return acc + " " + current;
      });
      return res;
    } else if (document.querySelector('.classes-to-remove').value.split(' ').length = 1) {
      // if you enter one word in the input fild
      let chRes = document.querySelector('.classes-to-remove').value.split(' ')[0].split('');
      if (chRes.length > 1) {
        // if the word have more than one liter 
            let res = chRes.reduce(function (acc, current) {
              acc =  acc.toLowerCase();
              current =  current.toLowerCase();
              return acc + current;
            });
            return res;
          } else {
            // if it have one liter
            let res = document.querySelector('.classes-to-remove').value.split(' ')[0].toLowerCase();
            return res;
            
          }
      }
    }
    let resPoints = resu().split(' ');
    if (resu().split(' ').length > 1) {
    for(let i = 0; i < resPoints.length; i++) {
      if (! current.classList.contains(`${resPoints[i]}`)) {
        current.classList.remove(`${resPoints[i]}`);
      }

    }
    } else if (resu().split(' ').length === 1) {
      if (resu().split(' ')[0].length > 1) {
        current.classList.remove(`${resPoints[0]}`);
      } else {
        current.classList.remove(`${resPoints[0]}`);
      }
    }
// addition the res (string) to current element ass a class 

  // if condition to add span his inner text is the classes of current element
              console.log(resPoints.length)
                for (let i = 0; i < resPoints.length; i++) {
                      document.querySelector(`[title="${resPoints[i]}"]`).remove();
                    
                  }
            document.querySelector('.classes-to-remove').value = '';
    } else {
    e.preventDefault();
    
          };
};


// ??????



