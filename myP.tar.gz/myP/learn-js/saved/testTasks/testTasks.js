
// work

let add = document.querySelector('.add');
let text = document.querySelector('.input');
let tasks = document.querySelector('.tasks')
let mainObj = [];


if (localStorage.getItem('tasks')) {
    let arr = JSON.parse(localStorage.getItem('tasks'));
    for(let i = 0; i < arr.length; i++) {
        let teNo = arr[i][1];
        let task = document.createElement('div');
        task.className = 'task';
        task.id = arr[i][0];
        task.title = teNo;
        let btn = document.createElement('button');
        btn.className = 'delete';
        btn.id = `d${arr[i][0]}`;
        btn.onclick = function () {
            // let arr = JSON.parse(localStorage.getItem('tasks'));
            let lArr = JSON.parse(localStorage.getItem('tasks'));
            console.log(this.id.slice(1))
            let delE = this.id.slice(1);
            let arr = lArr.filter(ele => ele[0] !== delE);
            localStorage.removeItem('tasks');
            localStorage.setItem('tasks', JSON.stringify(arr))
            document.getElementById(`${delE}`).remove();
        }
        
        btn.innerHTML = 'Delete';
        task.append(teNo);
        task.append(btn);
        tasks.append(task);
    }
    
}
add.onclick = function () {
    if (text.value !== '') {
        let teNo = document.createTextNode(text.value);
        
        let task = document.createElement('div');
        task.className = 'task';
        task.id = `${Math.floor(Math.random() * 1000)}`;
        task.title = `${text.value}`;
        let btn = document.createElement('button');
        btn.className = 'delete';
        btn.id = `d${task.id}`
        btn.onclick = function () {
            // let arr = JSON.parse(localStorage.getItem('tasks'));
            let lArr = JSON.parse(localStorage.getItem('tasks'));
            console.log(this.id.slice(1))
            let delE = this.id.slice(1);
            let arr = lArr.filter(ele => ele[0] !== delE);
            localStorage.removeItem('tasks');
            localStorage.setItem('tasks', JSON.stringify(arr))
            document.getElementById(`${delE}`).remove();
        }
        btn.innerHTML = 'Delete';
        task.append(teNo);
        task.append(btn);
        tasks.append(task);
        let obj = [task.id, task.title];
        
        mainObj.push(obj);
        localStorage.setItem('tasks', JSON.stringify(mainObj));

    } else {
        console.log('error')
    };
    text.value = '';
};
