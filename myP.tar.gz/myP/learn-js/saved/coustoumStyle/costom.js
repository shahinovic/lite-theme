if (localStorage.getItem('family')) {
    let res = document.querySelector('.results');
    let myArr = document.querySelectorAll('select')[0];
    console.log(`font-family: ${localStorage.getItem('family')};`)
    res.style = `font-family: ${localStorage.getItem('family')};`;

    for (let i = 0; i < myArr.options.length; i++) {
        myArr.options[i].removeAttribute('selected');
    }
    document.querySelector(`[value="${localStorage.getItem('family')}"]`).setAttribute('selected','')
}
// option 2
if (localStorage.getItem('color')) {
    let myArr = document.querySelectorAll('select')[1];
    console.log(`color: ${localStorage.getItem('color')};`)
    let res = document.querySelector('.results');
    
    for (let i = 0; i < myArr.options.length; i++) {
        myArr.options[i].removeAttribute('selected');
    }
    document.querySelector(`[value="${localStorage.getItem('color')}"]`).setAttribute('selected','')
    res.style.color  = ` ${localStorage.getItem('color')}`;
}
// option 3
if (localStorage.getItem('size')) {
    let myArr = document.querySelectorAll('select')[2];
    console.log(`size: ${localStorage.getItem('size')};`)
    let res = document.querySelector('.results');
    res.style.fontSize = `${localStorage.getItem('size')}px`;

    for (let i = 0; i < myArr.options.length; i++) {
        myArr.options[i].removeAttribute('selected');
    }
    document.querySelector(`[value="${localStorage.getItem('size')}"]`).setAttribute('selected','')
}
document.querySelectorAll('select')[0].onchange = function () {
    let res = document.querySelector('.results');
    let ind = document.querySelectorAll('select')[0].selectedIndex;
    let family = document.querySelectorAll('option')[ind].value;
    localStorage.setItem('family', family)
    let myArr = document.querySelectorAll('select')[0];
    for (let i = 0; i < myArr.options.length; i++) {
        myArr.options[i].removeAttribute('selected');
    }
    document.querySelector(`[value="${localStorage.getItem('family')}"]`).setAttribute('selected','')
    res.style.fontFamily = ` ${localStorage.getItem('family')}`;
}
// option 2 
document.querySelectorAll('select')[1].onchange = function () {
    let ind = document.querySelectorAll('select')[1].selectedIndex;
    let color = document.querySelectorAll('option')[ind + 3].value;
    localStorage.setItem('color', color)
    let myArr = document.querySelectorAll('select')[1];
    for (let i = 0; i < myArr.options.length; i++) {
        myArr.options[i].removeAttribute('selected');
    }
    
    document.querySelector(`[value="${color}"]`).setAttribute('selected', '')
    let res = document.querySelector('.results');
    res.style.color  = ` ${localStorage.getItem('color')}`;
}
// option 3
document.querySelectorAll('select')[2].onchange = function () {
    let ind = document.querySelectorAll('select')[2].selectedIndex;
    let size = document.querySelectorAll('option')[ind + 9].value;
    localStorage.setItem('size', size);
    let myArr = document.querySelectorAll('select')[2];
    console.log(`font-size: ${localStorage.getItem('size')}px;`)
    let res = document.querySelector('.results');
    res.style.fontSize = `${localStorage.getItem('size')}px`;

    for (let i = 0; i < myArr.options.length; i++) {
        myArr.options[i].removeAttribute('selected');
    }
    document.querySelector(`[value="${localStorage.getItem('size')}"]`).setAttribute('selected','')
}
