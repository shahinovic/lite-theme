let in1 = document.querySelector('[name="1"]');
let in2 = document.querySelector('[name="2"]');
let in3 = document.querySelector('[name="3"]');
let sel = document.querySelector('select');
let op1 = document.querySelector('[value="1"]');
let op2 = document.querySelector('[value="2"]');
let op3 = document.querySelector('[value="3"]');
let op4 = document.querySelector('[value="4"]');
let op5 = document.querySelector('[value="5"]');
let ind = sel.selectedIndex;
let arr = document.querySelectorAll('option');
let res = document.querySelectorAll('option')[ind];
let val = (ind + 1).toString();
if (sessionStorage.getItem('in1') || sessionStorage.getItem('in2') || sessionStorage.getItem('in3') || sessionStorage.getItem('val')) {
    in1.value = sessionStorage.getItem('in1')
    in2.value = sessionStorage.getItem('in2')
    in3.value = sessionStorage.getItem('in3')
    let arr = document.querySelectorAll('option');
    for (let i = 0; i < arr.length; i++) {
        document.querySelectorAll('option')[i].removeAttribute('selected');
    }
    document.querySelector(`[value="${sessionStorage.getItem('val')}"]`).setAttribute('selected', '');
}
in1.oninput = function () {
    sessionStorage.setItem('in1', in1.value);
}
in2.oninput = function () {
    sessionStorage.setItem('in2', in2.value);
}
in3.oninput = function () {
    sessionStorage.setItem('in3', in3.value);
}
sel.onchange = function () {
    let ind = sel.selectedIndex;
    let arr = document.querySelectorAll('option');
    let res = document.querySelectorAll('option')[ind];
    let val = (ind + 1).toString();
    sessionStorage.setItem('val', val);
    for (let i = 0; i < arr.length; i++) {
        document.querySelectorAll('option')[i].removeAttribute('selected');
    }
    res.setAttribute('selected', '');
}
