// work
let stHe = document.createElement('style');
document.head.append(stHe);
// header
document.body.style = 'height: 100vh; background-color: #eee;'
stHe.innerHTML = '* { padding: 0; margin: 0; box-sizing: border-box;  font-family: arial; }';
let header = document.createElement('div');
header.className = 'header';
document.body.append(header);
header.style = 'height: 50px; background-color: #fff; display: flex; justify-content: space-between;'
let logo = document.createElement('div');
header.append(logo);
logo.style = 'width: 100px; height: 100%; display: flex; justify-content: center; align-items: center; color: lightgreen; font-size: 1.5em; font-weight: bold; font-family: arial;';
logo.className = 'logo';
let loTx = document.createTextNode('Elzero');
logo.append(loTx);
let nav = document.createElement('ul');
header.append(nav);
nav.className = 'links';
nav.style = 'width: fit-content; display: inline-flex; justify-content: center; align-items: center; width: fit-content; background-color: #fff; order: 2; list-style: none;'
for (let i = 0; i < 4; i++) {
    let link = document.createElement('li');
    link.style = 'font-size: 16px; color: rgb(167 162 162); font-weight: bold; margin-right: 10px;';
    link.className = 'link';
    nav.append(link);
}
document.querySelectorAll('.link')[0].innerHTML = 'Home';
document.querySelectorAll('.link')[1].innerHTML = 'About';
document.querySelectorAll('.link')[2].innerHTML = 'Service';
document.querySelectorAll('.link')[3].innerHTML = 'Content';
// content 
let content = document.createElement('div');
content.className = 'content';
document.body.append(content);
content.style = 'height: calc(100% - 100px); display: grid; grid-template-columns: repeat(3, 30%); justify-content: space-evenly; align-content: space-evenly;';
for (let i = 0; i < 15; i++) {
    let Product = document.createElement('div');
    Product.className = 'Product';
    content.append(Product);
    Product.style = 'text-align: center; padding: 15px; background-color: #fff;'
    let spanTx = `${i + 1}`;
    let sp = document.createElement('span');
    sp.className = 'number';
    Product.append(sp);
    sp.style = 'display: block; margin-bottom: 10px;'
    sp.append(spanTx);
    let ProductTx = document.createTextNode('Product');
    Product.append(ProductTx);

};

let footer = document.createElement('footer');
footer.className = 'footer';
document.body.append(footer);
let footerTx = document.createTextNode('Copyright 2021');
footer.append(footerTx);
footer.style = 'background-color: lightgreen; font-size: 1.1em; color: #fff; font-weight: bold; height: 50px; display: flex; justify-content: center; align-items: center;'
