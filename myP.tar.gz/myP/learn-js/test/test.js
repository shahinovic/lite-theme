const user = {
    theName: "Osama",
    theAge: 39,
    theTitle: "Developer",
    theCountry: "Egypt",
  };

  const {theAge} = user;
  console.log(theAge)