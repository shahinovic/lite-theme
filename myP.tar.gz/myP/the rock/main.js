function moving() {
    document.getElementById('reload').style.cssText = 'display: block; opacity: 1;'
}
function btn_1_Change() {
    // document.getElementById('sus').style.cssText = 'animation: on-off 1s linear infinite;';
    document.getElementById('btn').style.cssText = 'display: none'
    document.getElementById('btn-0').style.cssText = 'color: #fff; font-size: 1em; bottom: 23%; width: 30px; height: 30px;     left: 41% !important; transition: 0,3s linear; transform: translate(-50%, -50%);';
    document.getElementById('btn-0').innerHTML = '<i class="fa-solid fa-shuffle"></i>';
    document.getElementById('vid-v2').style.cssText = 'display: none';
    document.getElementById('vid-v1').style.cssText = 'bottom: 0;animation: wi-hei 0.5s linear forwards;';
}
function btn_2_Change() {
    // document.getElementById('sus').style.cssText = 'animation: on-off 1s linear infinite;';
    document.getElementById('btn-0').style.cssText = 'display: none'
    document.getElementById('btn').style.cssText = 'color: #fff; font-size:1em; bottom: 23%; width: 30px; height: 30px;     left: 41% !important; transition: 0,3s linear; transform: translate(-50%, -50%);';
    document.getElementById('btn').innerHTML = '<i class="fa-solid fa-shuffle"></i>';
    document.getElementById('vid-v1').style.cssText = 'display: none';
    document.getElementById('vid-v2').style.cssText = 'bottom: 0;animation: wi-hei 0.5s linear forwards;';
}
function playPause1() { 

    setTimeout(function(){ 
        mediaPlayer1 = document.getElementById('vid-v1');
        
        if (mediaPlayer1.paused) {
        mediaPlayer1.play();
        document.getElementById('sus').style.cssText = 'animation-duration: 0.8s;';
        } else { 
        mediaPlayer1.pause();
        document.getElementById('sus').style.cssText = 'animation-duration: 0.8s; opacity: 0 !important;';
        } }, 500);
}
function playPause2() { 

    setTimeout(function(){ 
        mediaPlayer2 = document.getElementById('vid-v2');
        
        if (mediaPlayer2.paused) {
        mediaPlayer2.play(); 
        document.getElementById('sus').style.cssText = 'animation-duration: 0.8s;';
        } else { 
        mediaPlayer2.pause(); 
        document.getElementById('sus').style.cssText = 'animation-duration: 0.8s; opacity: 0 !important;';
        } }, 500);
}
function re() {
    location.reload()
}